<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Blog;
use Illuminate\Support\Facades\Input;
use Image;
use File;
class BlogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $objs =Blog::all();
      $data['objs'] = $objs;
      return view('auth.list.blog',$data);
      //insert database
      //$obj = new Blog();
      //$obj->topic = 'Test 123';
      //$obj->content = 'Hello';
      //$obj->user_id = 1;
      //$obj->save();

      //ดูค่าdatabase
      //$objs = Blog::find(1);
      //$objs = Blog::all();
      //dd($objs);

      //update
      //$obj = Blog::find(1);
      //$obj->topic = 'Helloeve';
      //$obj->save();

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        // load view create
        $data['method'] = "post";
        $data['url']    = url('auth/blog/');
        return view('auth.from.blog',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $obj = new Blog();
      $obj->topic = $request['topic'];
      $obj->content = $request['content'];
      if ($request->hasFile('image')) {
            $newfilename = str_random(10).'.'.
                $request->file('image')->getClientOriginalExtension();
                $request->file('image')->move(public_path().'/images/image-blog/', $newfilename);
            Image::make(public_path().'/images/image-blog/'.$newfilename);
            $obj->name_img = $newfilename;
        }
      $obj->save();
      return redirect(url('auth/blog'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $obj = blog::find($id);
        // load view to show
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $obj = blog::find($id);
        $data['url']    = url('admin/blog/'.$id);
        $data['method'] = "put";
        $data['obj'] = $obj;
        return view('auth.from.blog',$data);
        // load view to edit
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $obj = Blog::find($id);
      $obj->topic = $request['topic'];
      $obj->content = $request['content'];
      $obj->save();
      return redirect(url('auth/blog'));

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      //delete
      $obj = Blog::find($id);
      $obj->delete();
      return redirect(url('auth/blog'));
    }
}
