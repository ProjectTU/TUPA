<?php

namespace App\Http\Controllers;
use App\Blog;

use Illuminate\Http\Request;

class BlogController extends Controller
{
    function index()
    {
       $data = Blog::all();
      return view('TU.News',['data' => $data]);
    }

  

    function controller()
    {
      return view('TU.Topbar');
    }

    function staff()
    {
      return view('TU.staff');
    }

    function HistoryTH()
    {

      $data = Blog::all();
      return view('TU.HistoryTH',['data' => $data]);
    }

    function location()
    {
      return view('TU.location');
    }

    function News()
    {
      $data = Blog::all();
      return view('TU.News',['data' => $data]);
    }
    function course()
    {
      return view('TU.course');
    }


}
