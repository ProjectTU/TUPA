@extends('TU.Topbar')

@section('content')

@for ($item = 0; $item < count($data); $item++)
	<div float="left";><img src="{{asset('/images/image-blog/'.$data[$item]['name_img'])}}"></div>
	<div float="right;">
		<h1>{{$data[$item]['topic']}}</h1>
	<p>{{$data[$item]['content']}}<p>
	</div>
	
	
@endfor

@stop
