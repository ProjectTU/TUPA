 @extends('TU.Topbar')
@section('content')
<div class='ui1_box__inner'>
    <h1>{{$data ->topic}}</h1><br>
    <img src="{{ asset('/images/image-blog/'.$data->name_img) }}" alt="ERROR">

    <p>{{$data->content}}<p>
  </div>
</div>
@stopxs