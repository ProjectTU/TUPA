 @extends('TU.Topbar')
@section('content')

        <!-- Sections -->

		    <section id="portfolio-area" class="sections">
            <div class="container">
                <!-- Example row of columns -->
                <h1 id="h1">News</h1>
@for ($item = 0; $item < count($data); $item++)
                <div class="row">
					<div float="left";><img width='250px' height='250px'; src="{{asset('/images/image-blog/'.$data[$item]['name_img'])}}"></div>
	<div float="left;">
		<h1>{{$data[$item]['topic']}}</h1>
	<p>{{$data[$item]['content']}}<p>
		</div>
					</div>
						
						
@endfor
                </div>
        
            </div> <!-- /container -->       
        </section>
@stop
		
		
	
