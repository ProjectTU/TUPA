<!doctype html>

<html class="no-js" lang=""> 
    <head>
      <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        

          <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">

        <link href="{{ asset('css/plugins.css') }}" rel="stylesheet">
        <link href="{{ asset('css/opensans-web-font.css') }}" rel="stylesheet">
        <link href="{{ asset('css/montserrat-web-font.css') }}" rel="stylesheet">
       <link href="{{ asset('css/font-awesome.min') }}" rel="stylesheet">
       <link href="{{ asset('css/style.css') }}" rel="stylesheet">
       <link href="{{ asset('css/responsive.css') }}" rel="stylesheet">
       <script src="{{ asset('js/vendor/modernizr-2.8.3-respond-1.4.2.min.js') }}"></script>
    

        <style>
        #h1{text-align:center;}
        p.g1{text-align: center;font-size: 220%; }
        .con{float: left;margin-left: 20%;
        padding-left: 30px; }
        </style>
    </head>
    <body>
      
        
       
            <div class="container">
            
            <div class="row">
                
                <div class="navbar-header">
                 
                    
                    <div class="brand-bg">
                          
                    <a class="navbar-brand" href="">  <img src="{{ asset('images/logo.png') }}"/></a>
                    </div>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav pull-right">
                       

                        <li><a  href="{{ url('/News.php') }}"> {{ config('view.News', 'News') }}</a></li>
                        
                        <li><a  href="{{ url('/location.php') }}"> {{ config('view.location', 'Places') }}</a></li>
                       <li><a  href="{{ url('/staff.php') }}"> {{ config('view.staff', 'Staff') }}</a></li>
                        <li><a href="{{ url('/course.php') }}"> {{ config('view.course', 'Course') }}</a></li>
                                               
                    </ul>
                </div><!-- /.navbar-collapse -->
                </div>
                
            </div><!-- /.container-fluid -->
        </nav>

        <!--Home page style-->
        <header class="home-bg">
        <div class="overlay-img">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="header-details">
                            <h1>THAMMASART <br> UNIVERSITY PATTAYA<i class="fa fa-circle"></i></h1>
                            
                            
                        </div>
                    </div>
                    

                </div>
            </div>
        </div>  
        </header>

        <!-- Sections -->

            
        </section>
        
        
          @yield('content')
        
       
    
        <!--Footer-->
        <footer>
            <div class="container">
            <p class="g1">Thammasart University</h1>
          
                <div class="row">
                    <div class="con">
                    <p >หลักสูตร</p>
                    <p class="a">วิศวกรรมซอฟต์แวร์</p>
                    <p class="a">วิศวกรรมยานยนต์</p>

                    </div>
                    <div class="con"> 
                    <p>ติดต่อเรา</p>
                    <p>หมู่ 5 39/4 ตำบล โป่ง</p>
                    <p>อำเภอ บางละมุง ชลบุรี 20150</p>
                    <p>038 259 050</p>
    
                    </div>
                    
                </div>
            </div>
        </footer>


        
    </body>
</html>
