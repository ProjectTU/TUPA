 @extends('TU.Topbar')
@section('content')
		
		
		<section id="our-team" class="sections">
            <div class="container">
	                <!-- Example row of columns -->
    		<div id="content">
  
<p align="center">
	<strong >หลักสูตรวิศวกรรมศาสตรบัณฑิต </strong></p>
<p align="center">
	<strong>สาขาวิชาวิศวกรรมยานยนต์  </strong></p>
<p align="center">
	<strong>(หลักสูตรใหม่ พ.ศ.</strong><strong> 2557)</strong></p>
<p>
	&nbsp;</p>
<p>
	ชื่อสถาบันอุดมศึกษา&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; มหาวิทยาลัยธรรมศาสตร์</p>
<p>
	วิทยาเขต/คณะ/ภาควิชา&nbsp; &nbsp; ศูนย์รังสิต และศูนย์พัทยา คณะวิศวกรรมศาสตร์&nbsp;</p>
<p>
	<strong>1.&nbsp;&nbsp;&nbsp;&nbsp; ชื่อหลักสูตร</strong></p>
<p style="margin-left:18pt;">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ภาษาไทย&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp;&nbsp; หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมยานยนต์  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
<p style="margin-left:18pt;">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ภาษาอังกฤษ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp;&nbsp; Bachelor of Engineering Program in Automotive Engineering  (English Program)</p>
<p>
	<strong>2.&nbsp;&nbsp;&nbsp;&nbsp; ชื่อปริญญาและสาขาวิชา</strong></p>
<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ภาษาไทย&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ชื่อเต็ม&nbsp;&nbsp; วิศวกรรมศาสตรบัณฑิต (วิศวกรรมยานยนค์)<br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ชื่อย่อ&nbsp;&nbsp;&nbsp;&nbsp; วศ.บ. (วิศวกรรมยานยนค์)<br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ภาษาอังกฤษ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ชื่อเต็ม&nbsp;&nbsp; Bachelor of Engineering (Automotive Engineering)<br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ชื่อย่อ&nbsp;&nbsp;&nbsp;&nbsp; B. Eng. (Automotive Engineering)</p>
<p>
	<strong>3.&nbsp;&nbsp;&nbsp;&nbsp; วิชาเอก </strong><strong>-</strong></p>
<p>
	<strong>4.&nbsp;&nbsp;&nbsp;&nbsp; จำนวนหน่วยกิตที่เรียนตลอดหลักสูตร</strong></p>
<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; จำนวนหน่วยกิตตลอดหลักสูตร&nbsp; &nbsp;&nbsp;&nbsp; 146 &nbsp;&nbsp;&nbsp; หน่วยกิต</p>
<p>
	<strong>5.&nbsp;&nbsp;&nbsp;&nbsp; รูปแบบของหลักสูตร</strong></p>
<p>
	<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5.1&nbsp; รูปแบบ</strong></p>
<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เป็นหลักสูตรระดับปริญญาตรีหลักสูตร 4 ปี</p>
<p>
	<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5.2&nbsp; ภาษาที่ใช้</strong></p>
<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; หลักสูตรจัดการศึกษาเป็นภาษาอังกฤษ</p>
<p>
	<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5.3&nbsp; การรับเข้าศึกษา</strong></p>
<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; รับทั้งนักศึกษาไทยและนักศึกษาต่างชาติที่สามารถใช้ภาษาไทยและอังกฤษได้เป็นอย่างดี</p>
<p>
	<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5.4&nbsp; ความร่วมมือกับสถาบันอื่น</strong></p>
<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; เป็นหลักสูตรของสถาบันโดยเฉพาะ</p>
<p>
	<strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 5.5&nbsp; การให้ปริญญาแก่ผู้สำเร็จการศึกษา</strong></p>
<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ให้ปริญญาเพียงสาขาวิชาเดียว</p>
<p>
	<strong>6. อาชีพที่สามารถประกอบได้หลังสำเร็จการศึกษา</strong></p>
<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6.1 วิศวกรรมยานยนต์ โดยสามารถทำงานในอุตสาหกรรมยานยนต์ เช่น การออกแบบชิ้นส่วนยานยนต์ การออกแบบระบบในยานยนต์ และการควบคุมกระบวนการผลิตยานยนต์ เป็นต้น</p>
<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6.2 วิศวกรเครื่องกล โดยสามารถออกแบบ ควบคุม และซ่อมบำรุงเครื่องจักรกล ควบคุมการผลิตและกระบวนการต่างๆในโรงงานอุตสาหกรรม ออกแบบและควบคุมงานระบบต่างๆ เช่น ระบบปรับอากาศ ระบบ การลำเลียงน้ำในอาคาร รวมทั้งการวิเคราะห์และปรับปรุงการใช้พลังงานในโรงงาน อาคาร และหน่วยงานต่างๆ ได้</p>
<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6.3 นักวิจัยในสาขาวิศวกรรมยานยนต์ หรือ วิศวกรรมเครื่องกล </p>
<p>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6.4 ครูอาจารย์ในสถาบันการศึกษาทางด้านวิทยาศาสตร์และเทคโนโลยี<p>
<p>
	
<p>
	

    
  </div>            
					
				
                
            </div> <!-- /container -->       
        </section>
@stop		
	