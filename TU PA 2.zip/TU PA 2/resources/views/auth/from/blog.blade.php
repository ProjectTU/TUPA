
@extends('layouts.app')

@section('content')
<div class="container">
  <div class='row'>
    <h3>Form Create Content</h3>
    {!! Form::open(array('url' => $url,'files' => true ,'method' => 'post')) !!}
      {{ method_field($method) }}
      <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
      <div class="form-group">
        <label for="topic">Topic</label>
        <input type="text" class="form-control" name="topic" placeholder="Topic">
      </div>
      <div class="form-group">
        <?=Form::label('image', 'Image of Product:');?>
        <?= Form::file('image',null,['class'=>'form-control']); ?>
      </div>
      <div class="form-group">
        <label for="content">Content</label>
        <textarea class="form-control" name="content" rows="8" cols="40"></textarea>
      </div>

      <button type="submit" class="btn btn-default">Submit</button>
      {!! Form::close() !!}
  </div>
</div>

@stop
