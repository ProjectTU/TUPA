<?php $__env->startSection('content'); ?>
		
		
		<section id="our-team" class="sections">
            <div class="container">
                <!-- Example row of columns -->
                <div class="row">
						<div class="team-heading">
							<h1>Profressor</h1>
							<p>Profressor in Thammasart University Pattaya</p>
						</div>
				
				<div class="team-member">
					
					<div class="col-sm-4 col-sm-12 col-xs-12">
						<div class="team">
								<img src="<?php echo e(asset('images/man1.png')); ?>"/>
							<div class="team-info">
								<h3>คณบดี</h3>
								<h5>wprapat@engr.tu.ac.th</</h5>
								<p>รองศาสตราจารย์ ดร.ประภัสสร์ วังศกาญจน์</p>
							</div>
						</div>	
					</div>
					
					<div class="col-sm-4 col-sm-12 col-xs-12">
						<div class="team">
							<img src="<?php echo e(asset('images/man2.png')); ?>"/>
							<div class="team-info">
								<h3>ผู้ช่วยคณบดีฝ่ายกิจกรรมพิเศษ</h3>
								<h5>sirisilp@engr.tu.ac.th</h5>
								<p>อาจารย์ ศิริศิลป์ กองศิลป์</p>
							</div>
						</div>	
					</div>
					
					<div class="col-sm-4 col-sm-12 col-xs-12">
						<div class="team">
								<img src="<?php echo e(asset('images/man3.png')); ?>"/>
							<div class="team-info">
								<h3>ผู้ช่วยคณบดีฝ่ายสารสนเทศ</h3>
								<h5>psurasak@engr.tu.ac.th</h5>
								<p>อาจารย์สุรศักดิ์ เพ็ชรมณี</p>
						</div>	
					</div>
					
					
					
				</div>	
					
				</div>
                
            </div> <!-- /container -->       
        </section>
		
		
	
        <!--Footer-->
        <footer>
            <div class="container">
			<hr>
            	<div class="row">
				
            		<div class="col-md-6 col-sm-6 col-xs-12">
						
					</div>
					
            		<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="copyright">
							
						</div>
					</div>
					
            	</div>
            </div>
        </footer>


       
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('site.Topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>