 
<?php $__env->startSection('content'); ?>

        <!-- Sections -->

		    <section id="portfolio-area" class="sections">
            <div class="container">
                <!-- Example row of columns -->
                <h1 id="h1">News</h1>
<?php for($item = 0; $item < count($data); $item++): ?>
                <div class="row">
					<div float="left";><img width='250px' height='250px'; src="<?php echo e(asset('/images/image-blog/'.$data[$item]['name_img'])); ?>"></div>
	<div float="left;">
		<h1><?php echo e($data[$item]['topic']); ?></h1>
	<p><?php echo e($data[$item]['content']); ?><p>
		</div>
					</div>
						
						
<?php endfor; ?>
                </div>
        
            </div> <!-- /container -->       
        </section>
<?php $__env->stopSection(); ?>
		
		
	

<?php echo $__env->make('site.Topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>