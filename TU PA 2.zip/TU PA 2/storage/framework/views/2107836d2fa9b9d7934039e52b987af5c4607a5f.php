<?php $__env->startSection('content'); ?>

	<div id ="adminstrative board">
	<div class="adminstrativethai1">
	<h1>คณะผู้บริหาร</h1>
	</div>
	<div class="adminstrativethai2">




	<img src="AdminstrativeBoard/1.jpg" width="13%" align="left" >
	<FONT>


<p>&nbsp;&nbsp;&nbsp;&nbsp;ผู้บริหารคณะ</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;รองศาสตราจารย์ ดร. ประภัสสร์ วังศกาญจน์</p>



</FONT>

		</div>

		<div id ="one">

	<div class="adminstrativethai2">




	<img src="AdminstrativeBoard/2.jpg" width="13%" align="left" >
	<FONT>


<p>&nbsp;&nbsp;&nbsp;&nbsp;ผู้ช่วยคณบดีฝ่ายกิจกรรมพิเศษ</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;อาจารย์ศิริศิลป์ กองศิลป์</p>



</FONT>

		</div>

		<div id ="one">

	<div class="adminstrativethai2">




	<img src="AdminstrativeBoard/3.jpg" width="13%" align="left" >
	<FONT>


<p>&nbsp;&nbsp;&nbsp;&nbsp;รองผู้อำนวยการศูนย์คอมพิวเตอร์เเละสารสนเทศ</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;อาจารย์สุรศักดิ์ เพ็ชรมณี</p>



</FONT>

		</div>

		<div id ="one">

	<div class="adminstrativethai2">




	<img src="AdminstrativeBoard/4.jpg" width="13%" align="left" >
	<FONT>


<p>&nbsp;&nbsp;&nbsp;&nbsp;ผู้ช่วยคณบดีฝ่ายการนักศึกษา</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;อาจารย์ณัฐดนย์ พรรณุเจริญวงษ์</p>



</FONT>

		</div>

		<div id ="one">

	<div class="adminstrativethai2">




	<img src="AdminstrativeBoard/5.jpg" width="13%" align="left" >
	<FONT>


<p>&nbsp;&nbsp;&nbsp;&nbsp;ที่ปรึกษาด้านการบริหาร</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;นางสาวธันยลัลน์ คมคาย</p>



</FONT>

		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>