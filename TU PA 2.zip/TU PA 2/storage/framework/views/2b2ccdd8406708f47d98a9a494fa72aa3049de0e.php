<?php $__env->startSection('content'); ?>
<div class="container">
  <div class='row'>
    <h3>Form Create Content</h3>
    <?php echo Form::open(array('url' => $url,'files' => true ,'method' => 'post')); ?>

      <?php echo e(method_field($method)); ?>

      <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
      <div class="form-group">
        <label for="topic">Topic</label>
        <input type="text" class="form-control" name="topic" placeholder="Topic">
      </div>
      <div class="form-group">
        <?=Form::label('image', 'Image of Product:');?>
        <?= Form::file('image',null,['class'=>'form-control']); ?>
      </div>
      <div class="form-group">
        <label for="content">Content</label>
        <textarea class="form-control" name="content" rows="8" cols="40"></textarea>
      </div>

      <button type="submit" class="btn btn-default">Submit</button>
      <?php echo Form::close(); ?>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>