 
<?php $__env->startSection('content'); ?>
		
 <section id="portfolio-area" class="sections">
            <div class="container">
                <!-- Example row of columns -->
                <h1 id="h1">Places</h1>
                <div class="row">
					<div class="col-sm-6 col-sm-12 col-xs-12">
						<div class="portfolio">
						<img src="<?php echo e(asset('images/bo.jpg')); ?>"/>
							
						</div>
					</div>
					
					<div class="col-sm-5 col-sm-12 col-xs-12">
						<div class="portfolio">
						
						<div class="item">
						<h1>ตึกบรรยายเรียนรวม<i class="fa fa-circle"></i></h1>
						<h5>อาคารบรรยายเรียนรวมสะดวกพร้อมเดินทางแอร์เย็นฉำ่ำเพร้อมรับของไปรษณีย์</h5>
						
						
						
						</div>
						
						</div>
					</div>

                </div>
                <div class="row">
					<div class="col-sm-6 col-sm-12 col-xs-12">
						<div class="portfolio">
						<img src="<?php echo e(asset('images/shop.jpg')); ?>"/>
							
						</div>
					</div>
					
					<div class="col-sm-5 col-sm-12 col-xs-12">
						<div class="portfolio">
						
						<div class="item">
						<h1>ตึกปฎิบัติการ<i class="fa fa-circle"></i></h1>
						<h5>อาคารปฎิบัติการยาน์ยนต์มีห้องmacไม่พอต่อนักศึกษา</h5>
					
						
						</div>
						
						</div>
					</div>

                </div>
                <div class="row">
					<div class="col-sm-6 col-sm-12 col-xs-12">
						<div class="portfolio">
						<img src="<?php echo e(asset('images/bo.jpg')); ?>"/>
							
						</div>
					</div>
					
					<div class="col-sm-5 col-sm-12 col-xs-12">
						<div class="portfolio">
						
						<div class="item">
						<h1>ตึกบรรยายเรียนรวม<i class="fa fa-circle"></i></h1>
						<h5>อาคารบรรยายเรียนรวมสะดวกพร้อมเดินทางแอร์เย็นฉำ่ำเพร้อมรับของไปรษณีย์</h5>
						
						
						
						</div>
						
						</div>
					</div>

                </div>
            </div> <!-- /container -->       
        </section>
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('TU.Topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>