

<?php $__env->startSection('content'); ?>

<?php for($item = 0; $item < count($data); $item++): ?>
	<div float="left";><img src="<?php echo e(asset('/images/image-blog/'.$data[$item]['name_img'])); ?>"></div>
	<div float="right;">
		<h1><?php echo e($data[$item]['topic']); ?></h1>
	<p><?php echo e($data[$item]['content']); ?><p>
	</div>
	
	
<?php endfor; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.Topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>