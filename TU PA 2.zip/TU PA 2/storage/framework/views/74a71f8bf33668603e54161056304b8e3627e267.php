

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <a class="btn btn-primary" href="<?php echo e(url('admin/blog/create')); ?>">Create</a>
      <table class="table table-striped">
        <tr>
          <th>
            ID
          </th>
          <th>
            Topic
          </th>
          <th>
            Action
          </th>
        </tr>
        <?php $__currentLoopData = $objs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>
              <?php echo e($row->id); ?>

          </td>
          <td>
              <?php echo e($row->topic); ?>

          </td>
          <td>
            <a class="fl btn btn-primary" id="edit" href="<?php echo e(url('admin/blog/'.$row->id.'/edit')); ?>">EDIT</a>

            <form class="fl" action="<?php echo e(url('admin/blog/'.$row->id)); ?>" method="post" onsubmit="return(confirm('Do you want to delete this?'))">
              <?php echo e(method_field('DELETE')); ?>

              <?php echo e(csrf_field()); ?>

                <button type="submit" class="btn btn-danger">DELETE</button>
            </form>

          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>