<?php $__env->startSection('content'); ?>
<div id ="one">
	<div class="mapthai">
	<h4>คณะวิศวกรรมศาสตร์ มหาวิทยาลัยธรรมศาสตร์ ศูนย์พัทยา</h4>
	<p>มหาวิทยาลัยธรรมศาสตร์ ศูนย์พัทยา </p>
	<p>39/4 หมู่ 5 ต.โป่ง อ.บางละมุง จ.ชลบุรี 20150 </p>
	<p>โทร.038-259050-55 โทรสาร. 038-259069</p>
	<center>
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1944.4265108765605!2d100.99503310642108!3d12.917166607029154!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x14042f784f63e495!2z4Lih4Lir4Liy4Lin4Li04LiX4Lii4Liy4Lil4Lix4Lii4LiY4Lij4Lij4Lih4Lio4Liy4Liq4LiV4Lij4LmMIOC4qOC4ueC4meC4ouC5jOC4nuC4seC4l-C4ouC4sg!5e0!3m2!1sth!2sth!4v1488110507784" width="900" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
	</center>

	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>