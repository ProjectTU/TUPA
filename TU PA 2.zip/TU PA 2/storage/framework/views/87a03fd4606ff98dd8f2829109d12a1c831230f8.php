<?php $__env->startSection('content'); ?>
<div id ="historythai">
	<div class="historythai">
	<h2>ประวัติคณะวิศวกรรมศาสตร์</h2>
	<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;มหาวิทยาลัยธรรมศาสตร์ได้เริ่มดำเนินการเพื่อพัฒนามหาวิทยาลัยในด้านการจัดการเรียนการสอน ทางด้านวิทยาศาสตร์และเทคโนโลยีวิศวกรรมศาสตร์ ในช่วงการปรับแผนพัฒนาการศึกษาฉบับที่ 6 พ.ศ. 2533 - 2534 (2 ปีสุดท้ายของแผน) เพื่อให้มีส่วนในการผลิตวิศวกรสาขาต่างๆ ออกไปรับใช้สังคมและประเทศชาติ อันเป็นการตอบสนองนโยบายของรัฐในการผลิตบุคลากรที่มีความรู้ความสามารถใน สาขาวิชาวิศวกรรมศาสตร์ ซึ่งพระบาทสมเด็จพระเจ้าอยู่หัวภูมิพลอดุลยเดชฯ ทรงลง พระปรมาภิไธยในพระราชกฤษฎีกา จัดตั้งคณะวิศวกรรมศาสตร์ เมื่อวันเสาร์ที่ 19 สิงหาคม พ.ศ. 2532 มหาวิทยาลัยธรรมศาสตร์จึงกำหนดให้วันนี้เป็นวันสถาปนาคณะวิศวกรรม ศาสตร์ โดยเป็นคณะที่ 10 ของมหาวิทยาลัยธรรมศาสตร์ และเป็นคณะวิศวกรรมศาสตร์แห่งที่ 9 ในมหาวิทยาลัยของรัฐ โดยเริ่มมีการจัดการเรียนการสอนตั้งแต่ปีการศึกษา 2533 เป็นต้นมา ดังมีรายละเอียดต่อไปนี้</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; ปีการศึกษา 2533
เปิดรับนักศึกษา 2 สาขาวิชา คือ สาขาวิชาวิศวกรรมไฟฟ้า และสาขาวิชาวิศวกรรมอุตสาหการ</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;ปีการศึกษา 2534	เปิดรับนักศึกษา สาขาวิชาวิศวกรรมโยธา</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;ปีการศึกษา 2536	เปิดรับนักศึกษา สาขาวิชาวิศวกรรมเคมี</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;ปีการศึกษา 2538	เปิดรับนักศึกษา สาขาวิชาวิศวกรรมเครื่องกล</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;ปีการศึกษา 2539
เปิดรับนักศึกษาโครงการหลักสูตรวิศวกรรมศาสตรบัณฑิตสองสถาบัน โดยความร่วมมือกับมหาวิทยาลัยแห่งน็อตติ้งแฮมประเทศ&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;อังกฤษ 5 สาขาวิชา ได้แก่ สาขาวิชาวิศวกรรมไฟฟ้า สาขาวิชาวิศวกรรมอุตสาหการ สาขาวิชาวิศวกรรมโยธา สาขาวิชาวิศวกรรมเคมี &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;และสาขาวิชาวิศวกรรมเครื่องกล</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;ปีการศึกษา 2540
เปิดรับนักศึกษาหลักสูตรปริญญาโทสาขาวิชาวิศวกรรมอุตสาหการ และสาขาวิชาวิศวกรรมโยธา</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;ปีการศึกษา 2544
เปิดรับนักศึกษา โครงการหลักสูตรวิศวกรรมศาสตรบัณฑิตสองสถาบัน โดยความ ร่วมมือกับมหาวิทยาลัยแห่งรีไจนา ประเทศแคนาดา &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5 สาขาวิชา ได้แก่ สาขาวิชาวิศวกรรมไฟฟ้า สาขาวิชาวิศวกรรมอุตสาหการ สาขาวิชาวิศวกรรมโยธา สาขาวิชาวิศวกรรมเคมีและสาขาวิชาวิศวกรรม<br>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;เครื่องกล</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;ปีการศึกษา 2545
เปิดรับนักศึกษาหลักสูตรวิศวกรรมศาสตรบัณฑิต ภาคภาษาอังกฤษ 5 สาขาวิชาได้แก่ สาขาวิชาวิศวกรรมไฟฟ้า สาขาวิชาวิศวกรรม<br>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;อุตสาหการ สาขาวิชาวิศวกรรมโยธา สาขาวิชาวิศวกรรมเคมี และสาขาวิชาวิศวกรรมเครื่องกล</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;ปีการศึกษา 2545
เปิดรับนักศึกษา หลักสูตรปริญญาโท 2 สาขาวิชา ได้แก่ สาขาวิชาวิศวกรรมไฟฟ้าและสาขาวิชาเคมี</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;ปีการศึกษา 2545	เปิดรับนักศึกษา หลักสูตรปริญญาเอก สาขาวิชาวิศวกรรมโยธา</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;ปีการศึกษา 2545	เปิดหลักสูตรวิศวกรรมคอมพิวเตอร์</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;ปีการศึกษา 2551
เปิดหลักสูตรปริญญาตรี-โท วิศวกรรมศาสตร์และการจัดการเชิงธุรกิจ (Engineering and Business Management) และหลักสูตรปริญญา<br>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;โท-เอก วิศวกรรมทางการแพทย์ (Medical Engineering)</p>
	</div>

  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>