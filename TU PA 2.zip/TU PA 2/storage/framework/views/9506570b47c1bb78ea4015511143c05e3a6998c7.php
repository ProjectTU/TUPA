<html>

	<head>
    <meta charset="utf8">
		<title>home</title>

		<link rel="stylesheet" href="<?php echo e(URL::asset('css/nav.css')); ?>">


	</head>
	<body>
	<div class="container">

	<img src ="<?php echo e(URL::asset('images/newsheader.jpg')); ?>" width="945px" >
	<a href ="<?php echo e(URL::asset('HomeTH.php')); ?>"><img src="<?php echo e(URL::asset('images/thai.jpg')); ?>" width="55px">
	<a href ="HomePageEN.html"><img src="<?php echo e(URL::asset('images/england.jpg')); ?>" width="55px">





	<ul>
		<li><a href="<?php echo e(URL::asset('HomeTH.php')); ?>">หน้าหลัก</a></li>

		<li class="dropdown">
		<a href="#" class="dropbtn">เกี่ยวกับคณะ</a>
		<div class="dropdown-content" >
		<a href="<?php echo e(URL::asset('HistoryTH.php')); ?>">ประวัติ</a>
		<a href="<?php echo e(URL::asset('AdmiTH.php')); ?>">ผู้บริหารคณะ และ หน่วยงาน</a>
		<a href="<?php echo e(URL::asset('AddressTH.php')); ?>">ที่อยู่เเละแผนที่</a>


		<li><a href="<?php echo e(URL::asset('StudentLifeTH.php')); ?>">ชีวิตนักศึกษา</a></li>

		<li class="dropdown">
		<a href="#" class="dropbtn">หลักสูตร</a>
		<div class="dropdown-content">
		<a href="<?php echo e(URL::asset('AutoTH.php')); ?>">AUTOMOTIVE ENGINEER</a>
		<a href="<?php echo e(URL::asset('SoftTH.php')); ?>">SOFTWARE ENGINEER</a>

		<li><a href="<?php echo e(URL::asset('NewsTH.php')); ?>">ข่าวสารเเละกิจกรรม</a></li>





		<img class="mySlides" src="<?php echo e(URL::asset('images/pageonesix.jpg')); ?>" width="100%" height="50%">
		<img class="mySlides" src="<?php echo e(URL::asset('images/pageonenine.jpg')); ?>"width="100%" height="50%">
		<img class="mySlides" src="<?php echo e(URL::asset('images/pageoneeight.jpg')); ?>"width="100%" height="50%">
<script>
var slideIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > x.length) {slideIndex = 1}
    x[slideIndex-1].style.display = "block";
    setTimeout(carousel, 2000);
}
</script>


<br>
<?php echo $__env->yieldContent('content'); ?>


	<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  <br><br><br><br><br>

	<br>



  	<hr>



  	<footer>



  <div id ="footer">

  	<div class="footerleft">


  		<h3>ลิ้งที่เกี่ยวข้อง</h3>
  		<ul style="list-style: decimal">
  			<li><a href="https://www.engr.tu.ac.th/"target="_blank">คณะวิศวกรรศาสตร์ มหาลัยธรรมศาสตร์</a></li>
  			<li><a href="https://pattayacenter.tu.ac.th/"target="_blank">ธรรมศาสตร์ศูนย์พัทยา</a></li>
  			<li><a href="http://www2.citu.tu.ac.th/citu/www/content/%E0%B9%80%E0%B8%81%E0%B8%B5%E0%B9%88%E0%B8%A2%E0%B8%A7%E0%B8%81%E0%B8%B1%E0%B8%9A-learning-resort/"target="_blank">อุทยานการเรียนรู้&nbsp;&nbsp;&nbsp</a></li>
  			<li><a href="http://main.library.tu.ac.th/tulib2013/"target="_blank">สำนักหอสมุด&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp</a></li>
  		</ul>


  	</div>

  	<div class="footerright">
  		<h3>online</h3>
  		<a href ="https://www.facebook.com/pg/%E0%B8%84%E0%B8%93%E0%B8%B0%E0%B8%A7%E0%B8%B4%E0%B8%A8%E0%B8%A7%E0%B8%81%E0%B8%A3%E0%B8%A3%E0%B8%A1%E0%B8%A8%E0%B8%B2%E0%B8%AA%E0%B8%95%E0%B8%A3%E0%B9%8C-%E0%B8%A1%E0%B8%AB%E0%B8%B2%E0%B8%A7%E0%B8%B4%E0%B8%97%E0%B8%A2%E0%B8%B2%E0%B8%A5%E0%B8%B1%E0%B8%A2%E0%B8%98%E0%B8%A3%E0%B8%A3%E0%B8%A1%E0%B8%A8%E0%B8%B2%E0%B8%AA%E0%B8%95%E0%B8%A3%E0%B9%8C-%E0%B8%A8%E0%B8%B9%E0%B8%99%E0%B8%A2%E0%B9%8C%E0%B8%9E%E0%B8%B1%E0%B8%97%E0%B8%A2%E0%B8%B2-763195940468903/events/?ref=page_internal"target="_blank"><img src="<?php echo e(URL::asset('images/facebookk.jpg')); ?>" width ="28%"></a>
  		<a href ="https://www.twitter.com"target="_blank"><img src ="<?php echo e(URL::asset('images/twitterr.jpg')); ?>" width="28%"></a>
  	</div>
  	</footer>

  	</ul>

	</body>

</html>
