<?php $__env->startSection('content'); ?>
<div id ="one">
	<div class="neweng1">
	<h2>News & Events</h2>
	</div>
	<div class="neweng2">

	<a href ="News1TH.html"><h2 style="color : black">โครงการหลักสูตรนวัตกรรมทางวิศวกรรมศาสตร์ คณะวิศวกรรมศาสตร์ มหาวิทยาลัยธรรมศาสตร์</h2></a>


	<a href ="News1TH.html"><img src="image/โครงการ1.jpg" width="200px" align="left" ></a>
	<FONT>


<p>&nbsp; &nbsp;&nbsp; &nbsp;ได้เปิดสอนรายวิชา วพ. 320 การสื่อสารข้อมูลและเครือข่ายคอมพิวเตอร์

การศึกษาดูงานในครั้งนี้มีวัตถุประสงค์เพื่อให้&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;นักศึกษาเข้าใจในเนื้อหารายวิชาอย่างแท้จริง ทำให้เห็นองค์ประกอบภาพรวมในหัวข้อต่าง ๆ ของรายวิชา และเป็นการเสริม&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;สร้างศักยภาพให้แก่นักศึกษา สามารถนำไปประยุกต์ใช้ในการเรียนและการทำงานรวมถึงให้นักศึกษาได้รับประสบการณ์ตรง&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;ในเรื่องของอาชีพกับทางบริษัท ซิสโก้ ซีสเต็มส์ (ประเทศไทย) จำกัด</p><BR>

</FONT>






	<br>
	</div>
	<div id="two">

	<div class="neweng2">
	<a href ="News2TH.html" ><h2 style="color : black">โครงการหลักสูตรนวัตกรรมทางวิศวกรรมศาสตร์ คณะวิศวกรรมศาสตร์ มหาวิทยาลัยธรรมศาสตร์</h2></a>
	<a href="News2TH.html"><img src="image/โครงการ2.jpg" width="200px" align="left" ></a>




	<font>

<p>&nbsp; &nbsp;&nbsp; &nbsp;ได้เปิดสอนรายวิชา  วซ. 212 สถาปัตยกรรมและการออกแบบซอฟต์แวร์

การศึกษาดูงานในครั้งนี้มีวัตถุประสงค์เพื่อให้&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; นักศึกษาเข้าใจในเนื้อหารายวิชาอย่างแท้จริง ทำให้เห็นองค์ประกอบภาพรวมในหัวข้อต่าง ๆ ของรายวิชา และเป็นการเสริมสร้างศักยภาพให้แก่นักศึกษา สามารถนำไปประยุกต์ใช้ในการเรียนและการทำงานรวมถึงให้นักศึกษาได้รับประสบการณ์ตรงในเรื่องของอาชีพกับทางบริษัท ไมโครซอฟท์ ประเทศไทย จำกัด</p>
	</font>
	</div>
  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>